UnityThirdPersonTutorial
========================

Sample project showing third person camera behavior and Mecanim animations
